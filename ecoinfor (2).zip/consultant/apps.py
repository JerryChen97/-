from django.apps import AppConfig


class ConsultantConfig(AppConfig):
    name = 'consultant'
